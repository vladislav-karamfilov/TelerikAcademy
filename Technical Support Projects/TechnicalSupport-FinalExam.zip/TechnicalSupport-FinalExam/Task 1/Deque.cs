﻿namespace Deque
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Represents a linear collection that supports item insertion and removal at both ends.
    /// </summary>
    /// <typeparam name="T">The type of the items stored in the <typeparamref name="Deque"/>.</typeparam>
    public class Deque<T> : IDeque<T>
    {
        private readonly LinkedList<T> dequeRepresentation;

        /// <summary>
        /// Initializes a new empty instance of the <typeparamref name="Deque"/> class.
        /// </summary>
        public Deque()
        {
            this.dequeRepresentation = new LinkedList<T>();
        }

        /// <summary>
        /// Gets the number of items currently stored in the <typeparamref name="Deque"/>.
        /// </summary>
        public int Count
        {
            get { return this.dequeRepresentation.Count; }
        }

        /// <summary>
        /// Adds <paramref name="item"/> to the front of the <typeparamref name="Deque"/>.
        /// </summary>
        /// <param name="item">The item to be added to the <typeparamref name="Deque"/>.</param>7
        /// <remarks>The <paramref name="item"/> can be null.</remarks>
        public void PushFirst(T item)
        {
            this.dequeRepresentation.AddFirst(item);
        }

        /// <summary>
        /// Adds <paramref name="item"/> to the back of the <typeparamref name="Deque"/>.
        /// </summary>
        /// <param name="item">The item to be added to the <typeparamref name="Deque"/>.</param>
        /// <remarks>The <paramref name="item"/> can be null.</remarks>
        public void PushLast(T item)
        {
            this.dequeRepresentation.AddLast(item);
        }

        /// <summary>
        /// Retreives the item currently at the front of the <typeparamref name="Deque"/> 
        /// and removes it from the <typeparamref name="Deque"/>. 
        /// </summary>
        /// <returns>The item currently at the front of the <typeparamref name="Deque"/>.</returns>
        /// <exception cref="System.InvalidOperationException">The <typeparamref name="Deque"/> is empty.</exception>
        public T PopFirst()
        {
            if (this.dequeRepresentation.Count == 0)
            {
                throw new InvalidOperationException("Deque is empty. Cannot pop an item from an empty deque!");
            }

            LinkedListNode<T> firstitemNode = this.dequeRepresentation.First;
            T firstitem = firstitemNode.Value;
            
            this.dequeRepresentation.RemoveFirst();
            
            return firstitem;
        }

        /// <summary>
        /// Retreives the item currently at the back of the <typeparamref name="Deque"/> 
        /// and removes it from the <typeparamref name="Deque"/>.
        /// </summary>
        /// <returns>The item currently at the back of the <typeparamref name="Deque"/>.</returns>
        /// <exception cref="System.InvalidOperationException">The <typeparamref name="Deque"/> is empty.</exception>
        public T PopLast()
        {
            if (this.dequeRepresentation.Count == 0)
            {
                throw new InvalidOperationException("Deque is empty. Cannot pop an item from an empty deque!");
            }

            LinkedListNode<T> lastitemNode = this.dequeRepresentation.Last;
            T lastitem = lastitemNode.Value;
            
            this.dequeRepresentation.RemoveLast();
            
            return lastitem;
        }

        /// <summary>
        /// Retreives the item currently at the front of the <typeparamref name="Deque"/>. 
        /// </summary>
        /// <returns>The item currently at the front of the <typeparamref name="Deque"/>.</returns>
        /// <exception cref="System.InvalidOperationException">The <typeparamref name="Deque"/> is empty.</exception>
        public T PeekFirst()
        {
            if (this.dequeRepresentation.Count == 0)
            {
                throw new InvalidOperationException("Deque is empty. Cannot peek an item from an empty deque!");
            }

            LinkedListNode<T> firstitemNode = this.dequeRepresentation.First;
            T firstitem = firstitemNode.Value;
            return firstitem;
        }

        /// <summary>
        /// Retreives the item currently at the back of the <typeparamref name="Deque"/>. 
        /// </summary>
        /// <returns>The item currently at the back of the <typeparamref name="Deque"/>.</returns>
        /// <exception cref="System.InvalidOperationException">The <typeparamref name="Deque"/> is empty.</exception>
        public T PeekLast()
        {
            if (this.dequeRepresentation.Count == 0)
            {
                throw new InvalidOperationException("Deque is empty. Cannot peek an item from an empty deque!");
            }

            LinkedListNode<T> lastitemNode = this.dequeRepresentation.Last;
            T lastitem = lastitemNode.Value;
            return lastitem;
        }

        /// <summary>
        /// Removes all items from the <typeparamref name="Deque"/>.
        /// </summary>
        public void Clear()
        {
            this.dequeRepresentation.Clear();
        }

        /// <summary>
        /// Determines whether an item is in the <typeparamref name="Deque"/>.
        /// </summary>
        /// <param name="item">The item to locate in the <typeparamref name="Deque"/>.</param>
        /// <returns>
        /// True if the <paramref name="item"/> is found the <typeparamref name="Deque"/> and false otherwise.
        /// </returns>
        /// <remarks>The <paramref name="item"/> can be null.</remarks>
        public bool Contains(T item)
        {
            bool containsitem = this.dequeRepresentation.Contains(item);
            return containsitem;
        }
    }
}
