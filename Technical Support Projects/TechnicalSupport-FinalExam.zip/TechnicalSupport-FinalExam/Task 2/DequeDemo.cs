﻿namespace Deque.Demo
{
    using System;
    using Deque;

    class DequeDemo
    {
        static void Main()
        {
            Deque<int> deque = new Deque<int>();
            
            // Add elements at the front of the deque
            deque.PushFirst(2);
            deque.PushFirst(5);

            // Add elements at the back of the deque
            deque.PushLast(-2);
            deque.PushLast(-5);

            // Peek the element at the front of the deque
            int firstElement = deque.PeekFirst();
            Console.WriteLine("First element: " + firstElement);

            // Peek the element at the back of the deque
            int lastElement = deque.PeekLast();
            Console.WriteLine("Last element: " + lastElement);

            // Pop the element at the front of the deque
            int firstElementPopped = deque.PopFirst();
            Console.WriteLine("First element popped: " + firstElementPopped);
            Console.WriteLine("First element now: " + deque.PeekFirst());

            // Pop the element at the back of the deque
            int lastElementPopped = deque.PopLast();
            Console.WriteLine("Last element popped: " + lastElementPopped);
            Console.WriteLine("Last element now: " + deque.PeekLast());

            // Determine if an element is located in the deque
            int element = 4;
            bool containsElement = deque.Contains(element);
            Console.WriteLine("The deque contains {0}: {1}", element, containsElement);

            // Get the count of elements in the deque
            int elementsCount = deque.Count;
            Console.WriteLine("Elements count in the deque: " + elementsCount);

            // Clear the deque
            deque.Clear();
            Console.WriteLine("Elements count in the deque after clearing it: " + deque.Count);
        }
    }
}
