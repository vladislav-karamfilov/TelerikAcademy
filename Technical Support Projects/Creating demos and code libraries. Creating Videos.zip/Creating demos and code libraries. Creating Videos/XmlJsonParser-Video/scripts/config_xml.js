var TSC = TSC || {};

TSC.embedded_config_xml = '<x:xmpmeta xmlns:x="adobe:ns:meta/">\
   <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/" xmlns:xmpG="http://ns.adobe.com/xap/1.0/g/" xmlns:tsc="http://www.techsmith.com/xmp/tsc/" xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/" xmlns:tscDM="http://www.techsmith.com/xmp/tscDM/" xmlns:tscIQ="http://www.techsmith.com/xmp/tscIQ/" xmlns:tscHS="http://www.techsmith.com/xmp/tscHS/" xmlns:stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#" xmlns:stFnt="http://ns.adobe.com/xap/1.0/sType/Font#" xmlns:exif="http://ns.adobe.com/exif/1.0" xmlns:dc="http://purl.org/dc/elements/1.1/">\
      <rdf:Description tsc:version="2.0.1" dc:date="2013-08-12 03:31:38 PM" dc:source="Camtasia Studio,8.1.2,enu" dc:title="XmlJsonParser" tscDM:firstFrame="XmlJsonParser_First_Frame.png" tscDM:originId="1873561A-B61E-48B4-A1BB-8B517DEC7457" tscDM:project="XmlJsonParser">\
         <xmpDM:duration xmpDM:scale="1/1000" xmpDM:value="122100"/>\
         <xmpDM:videoFrameSize stDim:unit="pixel" stDim:h="480" stDim:w="774"/>\
         <tsc:langName>\
            <rdf:Bag>\
               <rdf:li xml:lang="en-US">English</rdf:li></rdf:Bag>\
         </tsc:langName>\
         <xmpDM:Tracks>\
            <rdf:Bag>\
               <rdf:li>\
                  <rdf:Description xmpDM:trackType="Hotspot" xmpDM:frameRate="f1000" xmpDM:trackName="Hotspots">\
                     <xmpDM:markers>\
                        <rdf:Seq>\
                           <rdf:li><rdf:Description xmp:label="1" xmpDM:startTime="8070" xmpDM:duration="2560" tscDM:boundingPoly="340,96;534,96;534,192;340,192;" tscDM:rotate="0.000000" tscHS:pause="1"/></rdf:li><rdf:li><rdf:Description xmp:label="2" xmpDM:startTime="23500" xmpDM:duration="2570" tscDM:boundingPoly="122,389;315,389;315,480;122,480;" tscDM:rotate="0.000000" tscHS:pause="1"/></rdf:li><rdf:li><rdf:Description xmp:label="3" xmpDM:startTime="33030" xmpDM:duration="2570" tscDM:boundingPoly="497,326;690,326;690,423;497,423;" tscDM:rotate="0.000000" tscHS:pause="1"/></rdf:li><rdf:li><rdf:Description xmp:label="4" xmpDM:startTime="48800" xmpDM:duration="2570" tscDM:boundingPoly="375,89;652,89;652,232;375,232;" tscDM:rotate="0.000000" tscHS:pause="1"/></rdf:li><rdf:li><rdf:Description xmp:label="5" xmpDM:startTime="80970" xmpDM:duration="2560" tscDM:boundingPoly="260,72;537,72;537,216;260,216;" tscDM:rotate="0.000000" tscHS:pause="1"/></rdf:li></rdf:Seq>\
                     </xmpDM:markers>\
                  </rdf:Description>\
               </rdf:li>\
            </rdf:Bag>\
         </xmpDM:Tracks>\
         <tscDM:controller>\
            <rdf:Description xmpDM:name="tscplayer">\
               <tscDM:parameters>\
                  <rdf:Bag>\
                     <rdf:li xmpDM:name="autohide" xmpDM:value="true"/><rdf:li xmpDM:name="autoplay" xmpDM:value="false"/><rdf:li xmpDM:name="loop" xmpDM:value="false"/><rdf:li xmpDM:name="searchable" xmpDM:value="false"/><rdf:li xmpDM:name="captionsenabled" xmpDM:value="false"/><rdf:li xmpDM:name="sidebarenabled" xmpDM:value="false"/><rdf:li xmpDM:name="unicodeenabled" xmpDM:value="false"/><rdf:li xmpDM:name="backgroundcolor" xmpDM:value="000000"/><rdf:li xmpDM:name="sidebarlocation" xmpDM:value="left"/><rdf:li xmpDM:name="endaction" xmpDM:value="stop"/><rdf:li xmpDM:name="endactionparam" xmpDM:value="true"/><rdf:li xmpDM:name="locale" xmpDM:value="en-US"/></rdf:Bag>\
               </tscDM:parameters>\
               <tscDM:controllerText>\
                  <rdf:Bag>\
                  </rdf:Bag>\
               </tscDM:controllerText>\
            </rdf:Description>\
         </tscDM:controller>\
         <tscDM:contentList>\
            <rdf:Description>\
               <tscDM:files>\
                  <rdf:Seq>\
                     <rdf:li xmpDM:name="0" xmpDM:value="XmlJsonParser.mp4"/><rdf:li xmpDM:name="1" xmpDM:value="XmlJsonParser_First_Frame.png"/></rdf:Seq>\
               </tscDM:files>\
            </rdf:Description>\
         </tscDM:contentList>\
      </rdf:Description>\
   </rdf:RDF>\
</x:xmpmeta>';
