﻿namespace XmlToJsonParser.Client
{
    using System;
    using System.IO;
    using System.Xml.Serialization;
    using XmlJsonParser;

    public class ClientUI
    {
        internal static void Main(string[] args)
        {
            Person newPerson = new Person();
            newPerson.Age = 22;
            newPerson.FirstName = "Pesho";
            newPerson.LastName = "Peshev";

            // Create an xml file 
            XmlSerializer serializer = new XmlSerializer(newPerson.GetType());
            TextWriter textWriter = new StreamWriter(@"../../person.xml");
            serializer.Serialize(textWriter, newPerson);
            textWriter.Close();

            // Parse the xml to JSON
            XmlJsonParser<Person> parseToJson = new XmlJsonParser<Person>();
            string jsonOutput = parseToJson.XmlToJson("../../person.xml");
            Console.WriteLine(jsonOutput);

            // Parse the created JSON to a new XML file
            XmlJsonParser<Person> parseToXml = new XmlJsonParser<Person>();
            parseToXml.JsonToXml(jsonOutput, "../../parsed-from-JSON-to-XML.xml");
        }
    }
}
