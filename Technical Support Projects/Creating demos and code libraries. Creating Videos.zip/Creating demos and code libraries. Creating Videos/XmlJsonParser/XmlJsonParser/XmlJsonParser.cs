﻿namespace XmlJsonParser
{
    using System;
    using System.IO;
    using System.Xml.Serialization;
    using Newtonsoft.Json;
    
    public class XmlJsonParser<T>
    {
        /// <summary>
        /// Converts an XML file to a JSON string.
        /// </summary>
        /// <param name="xmlFilePath">The path to the XML file which you want to convert to JSON.</param>
        /// <returns>A JSON string.</returns>
        public string XmlToJson(string xmlFilePath)
        {
            // Convert the XML code to an object
            T xmlToObject = default(T);

            XmlSerializer serializer = new XmlSerializer(typeof(T));

            StreamReader reader = new StreamReader(xmlFilePath);
            xmlToObject = (T)serializer.Deserialize(reader);
            reader.Close();

            // Parse the object to JSON
            string objectToJson = JsonConvert.SerializeObject(xmlToObject);
            return objectToJson;
        }

        /// <summary>
        /// Converts a JSON string to an XML and writes it to a file.
        /// </summary>
        /// <param name="jsonStringToConvert">The JSON string to convert to XML.</param>
        /// <param name="xmlFilePath">Path to the XML file.</param>
        public void JsonToXml(string jsonStringToConvert, string xmlFilePath)
        {
            // Convert the JSON code to an object
            T jsonToObject = default(T);

            object personJSON = JsonConvert.DeserializeObject(jsonStringToConvert, typeof(T));

            jsonToObject = (T)personJSON;

            // Parse the object to Xml
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            StreamWriter writer = new StreamWriter(xmlFilePath);
            serializer.Serialize(writer, jsonToObject);
            writer.Close();
        }
    }
}
